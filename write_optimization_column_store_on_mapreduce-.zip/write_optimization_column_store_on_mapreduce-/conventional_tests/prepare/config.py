__author__ = 'fyu'

import os,sys,time,datetime

import numpy as np
from base_class import BUN,TBUN

bat_format='%10d,%10d\n'
tbat_format='%5g,%10d,%10d\n'
