package basic;


/**
 * This is the sort merge class for data cleaning after AOC updates
 * @author fyu
 *
 */

import java.io.*;
import java.util.*;

public class Merger {
	
	public static void mergeWithBody(String body_file_name, String appendix, String output_file_name) throws IOException {
		// read in an appendix
		
		
	}
}
